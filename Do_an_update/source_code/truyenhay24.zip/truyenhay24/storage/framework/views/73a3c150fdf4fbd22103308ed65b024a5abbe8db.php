<!-- slide -->
<div class="container">
<h6 style="font-weight: bold">TRUYỆN HOT<i class="fa fa-fire" aria-hidden="true" style="margin-left: 10px"></i></h6>
<div class="container owl-carousel owl-theme ">
<?php $__currentLoopData = $truyen_hay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('xem-truyen/'.$value->slug_truyen)); ?>">
      <div class="item bg-title">
        <img  src="<?php echo e(asset('public/uploads/truyen/'.$value->hinhanh)); ?>">
        <div class="content content_1">
          <p class="title_truyen"><?php echo e($value->tentruyen); ?></p>
        </div>
      </div>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
</div>
</div>
<style>
  .content_1 {
    display: relative;
    padding: 0 10px;
  }
  .content_1 .title_truyen{
    margin-top: 10px;
    margin-bottom: 5px;
  }
  .title_truyen {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    display: block;
    width: 100%;
  }
</style><?php /**PATH C:\xampp\htdocs\truyenhay\phptruyen\truyenhay24\resources\views/pages/slide.blade.php ENDPATH**/ ?>