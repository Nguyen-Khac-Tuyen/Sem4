

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">Cập nhật truyện</div>
          <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
          <div class="card-body"> <?php if(session('status')): ?> <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>

            </div> <?php endif; ?> <form method="POST" action="<?php echo e(route('truyen.update',[$truyen->id])); ?>" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Tên truyện</label>
                <input id="slug" onkeyup="ChangeToSlug();" name="tentruyen" value="<?php echo e($truyen->tentruyen); ?>" type="text" class="form-control" placeholder="Tên thể loại...">
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Slug truyện</label>
                <input id="convert_slug" name="slug_truyen" value="<?php echo e($truyen->slug_truyen); ?>" type="text" class="form-control" placeholder="Slug thể loại...">
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Hình ảnh truyện</label>
                <input type="file" class="form-control-file" name="hinhanh" onchange="previewImage(this);">
                <div class="preview-image-container">
                <img id="image_s" class="image-hover" src="<?php echo e(asset('public/uploads/truyen/'.$truyen->hinhanh)); ?>" style="max-width:300px; max-height:300px;">
                <img id="preview-image" class="image-hover" src="" alt="Preview Image" style="display:none; max-width:300px; max-height:300px;">
                </div>
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Tóm tắt truyện</label>
                <textarea name="tomtat" id="noidung_chuong" class="form-control" rows="5" style="resize: none"><?php echo e($truyen->tomtat); ?></textarea>
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Tác giả</label>
                <input id="slug_tacgia" name="tacgia" onkeyup="ChangeToSlugTacGia();" value="<?php echo e($truyen->tacgia); ?>" type="text" class="form-control" placeholder="Tên tác giả...">
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Slug tác giả</label>
                <input id="convert_slug_tacgia"  name="slug_tacgia" value="<?php echo e($truyen->slug_tacgia); ?>" type="text" class="form-control" placeholder="Slug tác giả...">
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Từ khóa</label>
                <input name="tukhoa" value="<?php echo e($truyen->tukhoa); ?>" type="text" class="form-control" placeholder="Từ khóa...">
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Thể loại truyện</label>
                <select name="theloai" class="form-select" aria-label="Default select example">
                    <?php $__currentLoopData = $theloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $muc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($muc->id==$truyen->theloai_id ? 'selected' : ''); ?> value="<?php echo e($muc->id); ?>"><?php echo e($muc->tentheloai); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>
              
              
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Kích hoạt</label>
                <select name="kichhoat" class="form-select" aria-label="Default select example">
                    <?php if($truyen->kichhoat==0): ?>
                    <option selected value="0">Kích hoạt</option>
                    <option value="1">Không kích hoạt</option>
                    <?php else: ?>
                    <option value="0">Kích hoạt</option>
                    <option selected value="1">Không kích hoạt</option>
                    <?php endif; ?>
                  </select>
              </div>
              <button type="submit" name="themtruyen" class="btn btn-primary">Cập nhật</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\truyenhay\phptruyen\truyenhay24\resources\views/admincp/truyen/edit.blade.php ENDPATH**/ ?>