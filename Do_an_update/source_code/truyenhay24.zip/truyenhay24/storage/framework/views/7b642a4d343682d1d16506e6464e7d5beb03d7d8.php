 <?php $__env->startSection('slide'); ?> <?php echo $__env->make('pages.slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php $__env->stopSection(); ?> <?php $__env->startSection('content'); ?>
<!-- TRUYỆN MỚI CẬP NHẬT -->
<div class="container">
  <div style="margin-top: 30px">
    <div style="display: flex; justify-content: space-between; margin-bottom: 10px">
      <h6 style="font-weight: bold">TRUYỆN MỚI CẬP NHẬT <i class="fa fa-star" aria-hidden="true" style="margin-left: 10px"></i>
      </h6>
    </div>

    <div class="container album py-1">
      <div>
        <div class="row row-cols-1 row-cols-sm-3 row-cols-md-4 row-cols-lg-5 row-cols-xl-6 g-3"> <?php $__currentLoopData = $truyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <div class="col col-content">
            <a href="<?php echo e(url('xem-truyen/'.$value->slug_truyen)); ?>" class="col-sm-9 d-flex flex-column" style="width: 130px">
              <img class="image-hover" src="<?php echo e(asset('public/uploads/truyen/'.$value->hinhanh)); ?>">
              <div class="d-block justify-content-center align-items-center" style="margin-top: 12px">
                <h6 class="text-center fw-bold" style="max-height: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: block; width: 100%;"><?php echo e($value->tentruyen); ?></h6>
                <div class="d-flex justify-content-center align-items-center">
                  <button type="button" class="btn btn-sm btn-warning" style="max-height: 80px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: block; width: 100%;"><?php echo e($value->tacgia); ?></button>
                </div>
              </div>
            </a>
          </div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
      </div>
    </div>
    <!-- paginate -->
    <div class="d-flex flex-row-reverse mt-3">
    <?php echo e($truyen->links()); ?>

    </div>


  </div>
</div>
<style>
  a {
    text-decoration: none;
  }
</style> <?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\truyenhay24\resources\views/pages/home.blade.php ENDPATH**/ ?>