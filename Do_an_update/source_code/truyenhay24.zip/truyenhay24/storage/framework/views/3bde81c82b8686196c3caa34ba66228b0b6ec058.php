

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">Cập nhật chương</div>
          <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
          <div class="card-body"> <?php if(session('status')): ?> <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>

            </div> <?php endif; ?> <form method="POST" action="<?php echo e(route('chuong.update',[$chuong->id])); ?>">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Tiêu đề</label>
                <input id="slug" name="tieude" onkeyup="ChangeToSlug();" value="<?php echo e($chuong->tieude); ?>" type="text" class="form-control" placeholder="Tên chương...">
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Slug chương</label>
                <input id="convert_slug"  name="slug_chuong" value="<?php echo e($chuong->slug_chuong); ?>" type="text" class="form-control" placeholder="Slug chương...">
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Thuộc truyện</label>
                <select name="truyen_id" class="form-select" aria-label="Default select example">
                  <?php $__currentLoopData = $truyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($chuong->truyen_id==$value->id ? 'selected' : ''); ?> value="<?php echo e($value->id); ?>"><?php echo e($value->tentruyen); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Nội dung</label>
                <textarea name="noidung" id="noidung_chuong" class="form-control" rows="5" value="<?php echo e($chuong->noidung); ?>}"><?php echo e($chuong->noidung); ?></textarea>
              </div>



              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Kích hoạt</label>
                <select name="kichhoat" class="form-select" aria-label="Default select example">
                <?php if($chuong->kichhoat==0): ?>
                    <option selected value="0">Kích hoạt</option>
                    <option value="1">Không kích hoạt</option>
                    <?php else: ?>
                    <option value="0">Kích hoạt</option>
                    <option selected value="1">Không kích hoạt</option>
                    <?php endif; ?>
                  </select>
              </div>
              <button type="submit" name="themchuong" class="btn btn-primary">Cập nhật</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\truyenhay\phptruyen\truyenhay24\resources\views/admincp/chuong/edit.blade.php ENDPATH**/ ?>