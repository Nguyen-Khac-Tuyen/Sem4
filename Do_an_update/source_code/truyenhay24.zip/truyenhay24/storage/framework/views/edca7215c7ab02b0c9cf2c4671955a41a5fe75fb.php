

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">Cập nhật thể loại</div>
          <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
          <div class="card-body"> <?php if(session('status')): ?> <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>

            </div> <?php endif; ?> <form method="POST" action="<?php echo e(route('theloai.update',[$theloai->id])); ?>">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Tên thể loại</label>
                <input id="slug" onkeyup="ChangeToSlug();" name="tentheloai" value="<?php echo e($theloai->tentheloai); ?>" type="text" class="form-control" placeholder="Tên thể loại...">
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Slug thể loại</label>
                <input id="convert_slug" name="slug_theloai" value="<?php echo e($theloai->slug_theloai); ?>" type="text" class="form-control" placeholder="Slug thể loại...">
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Kích hoạt</label>
                <select name="kichhoat" class="form-select" aria-label="Default select example">
                    <?php if($theloai->kichhoat==0): ?>
                    <option selected value="0">Kích hoạt</option>
                    <option value="1">Không kích hoạt</option>
                    <?php else: ?>
                    <option value="0">Kích hoạt</option>
                    <option selected value="1">Không kích hoạt</option>
                    <?php endif; ?>
                  </select>
              </div>
              <button type="submit" name="themtheloai" class="btn btn-primary">Cập nhật</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\truyenhay\phptruyen\truyenhay24\resources\views/admincp/theloaitruyen/edit.blade.php ENDPATH**/ ?>