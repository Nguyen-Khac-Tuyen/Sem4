
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Liệt kê chương</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <form autocomplete="off" method="POST" action="<?php echo e(url('tim-kiem-chuong/')); ?>" class="d-flex" style="margin-bottom: 10px">
                    <?php echo csrf_field(); ?>
        <input name="tukhoa" class="form-control me-2" type="search" placeholder="Tìm kiếm" aria-label="Search">
        <button class="btn btn-warning text-light" type="submit">
        <i class="fa fa-search" aria-hidden="true"></i>
        </button>
      </form>
      <?php
        $count = count($chuong_t);
        ?>
        <?php if($count==0): ?>
        <div class="col-md-12">
            <div class="card box-shadow bg-warning">
                <div class="card-body">
                    <p class="text-danger">Không tìm thấy chương truyện vui lòng quay lại sau.....</p>
                </div>
            </div>
        </div>
        <?php else: ?>

                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col" class="col-md-3">Tiêu đề</th>
                            <th scope="col">Thuộc truyện</th>
                            <th scope="col" class="col-md-5">Nội dung</th>
                            <th scope="col">Kích hoạt</th>
                            <th scope="col">Quản lý</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $chuong_t; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $chap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <th scope="row"><?php echo e($key); ?></th>
                            <td><?php echo e($chap->tieude); ?></td>
                            <td><?php echo e($chap->truyen->tentruyen); ?></td>
                            <td>
                            <div class="noidung"> {<?php echo $chap->noidung; ?>}</div>
                           </td>
                            <td>
                                <?php if($chap->kichhoat==0): ?>
                                <span class="text text-success">Kích hoạt</span>
                                <?php else: ?>
                                <span class="text text-danger">Không kích hoạt</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('chuong.edit',[$chap->id])); ?>" class="btn btn-primary" style="margin-bottom: 10px">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>
                                <form action="<?php echo e(route('chuong.destroy',[$chap->id])); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button onclick="return confirm('Bạn có muốn xóa chương này không ?');" class="btn btn-danger">
                                        <i class="fa fa-trash" aria-hidden="true"></i>
                                    </button>
                                </form>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                      <?php endif; ?>
                
                    </div>
            </div>
            <div class="d-flex flex-row-reverse mt-3">
    <?php echo e($chuong_t->links()); ?>

    </div>
        </div>
    </div>
</div>
<style>
.noidung {
height: 200px;
overflow-y: hidden;
}
.noidung:hover {
height: 200px;
overflow-y: scroll !important;
}
      /* Style for the pagination links */
      .pagination {
  display: flex;
  justify-content: center;
 
}

.pagination li {
  display: inline-block;
  margin-right: 10px;
  font-size: 16px;
}

.pagination li a {
  display: block;
  background-color: #f5f5f5;
  color: #333;
  border-radius: 5px;
}

.pagination li a:hover {
  background-color: #333;
  color: #fff;
}

.pagination .active a {
  background-color: #333;
  color: #fff;
}
.page-link.active, .active > .page-link {
  border-radius: 5px;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\truyenhay\phptruyen\truyenhay24\resources\views/admincp/chuong/index.blade.php ENDPATH**/ ?>