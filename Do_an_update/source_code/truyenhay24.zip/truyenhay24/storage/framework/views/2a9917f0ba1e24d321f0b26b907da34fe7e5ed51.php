
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Liệt kê thể loại</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                <!-- tim kiem -->
                <form autocomplete="off" class="d-block" method="POST" action="<?php echo e(url('tim-kiem/')); ?>">
                  <?php echo csrf_field(); ?>
                  <div class="d-flex">
                  <input class="form-control" id="keywords" name="tukhoa" type="search" placeholder="Tìm kiếm..." aria-label="Search">
                  <button class="btn btn-warning text-light" style="margin-left: 10px" type="submit">
                      <i class="fa fa-search" aria-hidden="true"></i>
                  </button>
                  </div>
                    <div id="search_ajax" style="margin-top: 10px"></div>
                  </form>
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Tên thể loại</th>
                            <th scope="col">Kích hoạt</th>
                            <th scope="col">Quản lý</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $theloaitruyen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $theloai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <th scope="row"><?php echo e($key); ?></th>
                            <td><?php echo e($theloai->tentheloai); ?></td>
                            <td>
                                <?php if($theloai->kichhoat==0): ?>
                                <span class="text text-success">Kích hoạt</span>
                                <?php else: ?>
                                <span class="text text-danger">Không kích hoạt</span>
                                <?php endif; ?>
                            </td>
                            <td style="display:flex">
                                <a href="<?php echo e(route('theloai.edit',[$theloai->id])); ?>" class="btn btn-primary" style="margin-right: 10px">
                                    <i class="fa fa-pencil" aria-hidden="true"></i>
                                </a>
                                <form action="<?php echo e(route('theloai.destroy',[$theloai->id])); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button onclick="return confirm('Bạn có muốn xóa thể loại này không ?');" class="btn btn-danger">
                                        <i class="fa fa-trash" aria-hidden="true"></i>
                                    </button>
                                </form>
                            </td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\truyenhay\phptruyen\truyenhay24\resources\views/admincp/theloaitruyen/timkiem.blade.php ENDPATH**/ ?>