

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="row justify-content-center">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">Thêm </div>
          <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
          <div class="card-body"> <?php if(session('status')): ?> <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>

            </div> <?php endif; ?> <form method="POST" action="<?php echo e(route('theloai.store')); ?>">
                <?php echo csrf_field(); ?>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Tên thể loại</label>
                <input id="slug" name="tentheloai" onkeyup="ChangeToSlug();" value="<?php echo e(old('tentheloai')); ?>" type="text" class="form-control" placeholder="Tên thể loại...">
              </div>

              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Slug thể loại</label>
                <input id="convert_slug"  name="slug_theloai" value="<?php echo e(old('slug_theloai')); ?>" type="text" class="form-control" placeholder="Slug thể loại...">
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Kích hoạt</label>
                <select name="kichhoat" class="form-select" aria-label="Default select example">
                    <option value="0" <?php if(old('kichhoat') == '0'): ?> selected <?php endif; ?>>Kích hoạt</option>

                    <option value="1" <?php if(old('kichhoat') == '1'): ?> selected <?php endif; ?>>Không kích hoạt</option>
                  </select>
              </div>
              <button type="submit" name="themtheloai" class="btn btn-primary">Thêm</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\truyenhay\phptruyen\truyenhay24\resources\views/admincp/theloaitruyen/create.blade.php ENDPATH**/ ?>